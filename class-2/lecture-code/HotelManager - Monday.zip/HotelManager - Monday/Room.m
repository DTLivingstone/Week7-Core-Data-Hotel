//
//  Room.m
//  HotelManager
//
//  Created by Adam Wallraff on 7/19/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

#import "Room.h"
#import "Hotel.h"
#import "Reservation.h"

@implementation Room

// Insert code here to add functionality to your managed object subclass

@end
