//
//  Hotel.m
//  HotelManager
//
//  Created by Michael Babiy on 11/30/15.
//  Copyright © 2015 Michael Babiy. All rights reserved.
//

#import "Hotel.h"
#import "Room.h"

@implementation Hotel

// Insert code here to add functionality to your managed object subclass

@end
