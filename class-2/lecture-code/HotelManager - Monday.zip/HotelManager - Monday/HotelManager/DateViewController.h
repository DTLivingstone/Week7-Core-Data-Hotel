//
//  DateViewController.h
//  HotelManager
//
//  Created by Adam Wallraff on 7/19/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DateViewController : UIViewController

@end
