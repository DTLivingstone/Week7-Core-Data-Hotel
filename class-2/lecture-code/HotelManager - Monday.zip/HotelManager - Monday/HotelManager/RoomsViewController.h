//
//  RoomsViewController.h
//  HotelManager
//
//  Created by Michael Babiy on 11/30/15.
//  Copyright © 2015 Michael Babiy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Hotel.h"

@interface RoomsViewController : UIViewController

@property (strong, nonatomic) Hotel *hotel;

@end
