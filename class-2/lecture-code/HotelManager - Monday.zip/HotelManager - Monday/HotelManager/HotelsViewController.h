//
//  HotelsViewController.h
//  HotelManager
//
//  Created by Michael Babiy on 11/30/15.
//  Copyright © 2015 Michael Babiy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotelsViewController : UIViewController

@end
